- NAME: MANEESH WIJEWARDHANA
- ID: 1125828
- COURSE: CIS\*3110 ASSIGNMENT 2 - CPU SCHEDULER
- DUE DATE: MARCH 19

# COMPILATION AND RUNNING

- To compile, run make which will create the simcpu binary, then run ./simcpu with the desired flags
- Example: ./simcpu [-d] [-v] [-r quantum] < input.txt
