NAME: MANEESH WIJEWARDHANA
ID: 1125828
COURSE: CIS\*3490
DUE DATE: MARCH 28

ASSIGNMENT 4

# To compile and run

- Run make and then ./A4
- A prompt will appear and choose what option you would like to see
- Part 1 has the hardcoded file data_A4_Q1.txt but Part 2 you may enter whatever filename you would like
