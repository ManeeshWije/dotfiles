DROP TABLE  DOWNLOAD;
\! echo Deleted DOWNLOAD table
DROP TABLE MODIFICATION;
\! echo Deleted MODIFICATION table
DROP TABLE FILE;
\! echo Deleted FILE table
\! echo done!
