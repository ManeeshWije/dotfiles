package lab5;

public class Main {

    public static void main(String[] args) {
        GUI window = new GUI();
        window.setVisible(true);
    }
}
